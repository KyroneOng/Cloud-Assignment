<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<?php 
  
        $servername = ""; //set the servername
	$username = ""; //set the server username
	$password = ""; // set the server password (you must put password here if your using live server)
	$dbname = "bookings"; // set the table name

	$mysqli = new mysqli($servername, $username, $password, $dbname);

	if ($mysqli->connect_errno) {
	  echo "Failed to connect to MySQL: " . $mysqli->connect_error;
	  exit();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
     <style>
        table,td,th,tr{
            border:1px solid black;
        }
        
        #table1{
            border-collapse: collapse;
            text-align: center;
            width: 100%;
        }
        
        table{
            width: 97%;
            margin: 10px auto;
            border-collapse: collapse;
        }

        td{
            padding: 8px 15px;
            border:2px solid white;
            font-weight:bold;
        }
        
        .edit{
            color:white;
            border: 2px solid white;
            border-radius: 8px;
            padding: 5px;
            width:8%;
            height:50%;
            background-color:red;
            
        }
        
        .remove{
            margin-left:10px;
            color:white;
            border: 2px solid white;
            border-radius: 8px;
            padding: 5px;
            width:9%;
            height:50%;
            background-color:red;
        }
        
        .edit:hover,.remove:hover{
            background-color:#ff6666;
            color:black;
        }
    </style>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Table Lists</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Amatic+SC:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="vendor/aos/aos.css" rel="stylesheet">
  <link href="vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="css/main.css" rel="stylesheet">
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center me-auto me-lg-0">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1>Beauty In The Pot<span>.</span></h1>
      </a>
      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>

    </div>
  </header><!-- End Header -->

 
    <!-- ======= Book A Table Section ======= -->
    <section id="book-a-table" class="book-a-table" style="margin-top:10px;">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
            <h2 style="font-size: 25px;color:black;font-weight:bold;color:red;margin-top:30px;">Customer Book Table Lists</h2>
        </div>
            <table id="table1">
                <thead style="border-bottom: 1px solid black;">
                    <tr>
                        <th class="name" id="name">Name</th>
                        <th class="phone" id="phone">Phone</th>
                        <th class="date" id="date">Date</th>
                        <th class="time" id="time">Time</th>
                        <th class="people" id="people">People</th>
                    </tr>
                </thead>
                <tbody style="font-weight:normal;">
                    <tr>
                            
                            <?php
                                $data1 = mysqli_query($mysqli,"SELECT * FROM bookings");
                                    $no = 1;
                                    //print out data from database
                                    while($info1=mysqli_fetch_array($data1)){

                                ?>
                                 <tr class="list" id="bookList">
                                    <td><?php echo $info1['name'];?></td>
                                    <td><?php echo $info1['phone'];?></td>
                                    <td><?php echo $info1['date'];?></td>
                                    <td><?php echo $info1['time'];?></td>
                                    <td><?php echo $info1['people'];?></td>
                                 </tr>
                                   
                            <div class="form_action--button">
                            <button class="edit"><?php echo '<form method="POST" action="edit.php"></form>'?>Edit</button>               
                            <button class="remove"><?php echo '<form method="POST" action="delete.php"></form>'?>Remove</button>
                            </div>
                
                            <?php
                                        $no++;
                                    }
                            ?>
                    </tr>
                </tbody>
            </table>
      </div>
    </section><!-- End Book A Table Section -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">

    <div class="container">
      <div class="row gy-3">
        <div class="col-lg-3 col-md-6 d-flex">
          <i class="bi bi-geo-alt icon"></i>
          <div>
            <h4>Address</h4>
            <p>
              4, Gurney Plaza <br>
              11233 Penang<br>
            </p>
          </div>

        </div>

        <div class="col-lg-3 col-md-6 footer-links d-flex">
          <i class="bi bi-telephone icon"></i>
          <div>
            <h4>Reservations</h4>
            <p>
              <strong>Phone:</strong> 04-89072820<br>
              <strong>Email:</strong> beauty@example.com<br>
            </p>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 footer-links d-flex">
          <i class="bi bi-clock icon"></i>
          <div>
            <h4>Opening Hours</h4>
            <p>
              <strong>Mon-Sat: 11AM</strong> - 23PM<br>
              Sunday: Closed
            </p>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 footer-links">
          <h4>Follow Us</h4>
          <div class="social-links d-flex">
            <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
            <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
            <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
            <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>

      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Beauty In The Pot</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/yummy-bootstrap-restaurant-website-template/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>

  </footer><!-- End Footer -->
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/aos/aos.js"></script>
  <script src="vendor/glightbox/js/glightbox.min.js"></script>
  <script src="vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="vendor/swiper/swiper-bundle.min.js"></script>
  <script src="vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="js/main.js"></script>
  <script src="script.js"></script>

</body>

</html>
