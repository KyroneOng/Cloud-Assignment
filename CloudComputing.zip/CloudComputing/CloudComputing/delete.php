<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

$request = $_REQUEST; //a PHP Super Global variable which used to collect data after submitting it from the form
	$name = $request['name']; 
        $phone = $request['phone'];
        $date = $request['date'];
        $time = $request['time'];
        $people = $request['people'];

	$servername = "assignmentdatabase.cl1onx30vfoi.us-east-1.rds.amazonaws.com"; //set the servername
	$username = "KaiRong"; //set the server username
	$password = "kairong031213"; // set the server password (you must put password here if your using live server)
	$dbname = "assignment"; // set the table name

	$mysqli = new mysqli($servername, $username, $password, $dbname);

	if ($mysqli->connect_errno) {
	  echo "Failed to connect to MySQL: " . $mysqli->connect_error;
	  exit();
	}

	// Set the INSERT SQL data
	$sql = "DELETE bookings SET phone='".$phone."', date='".$date."', time='".$time."', people='".$people."' WHERE name='".$name."'";

	// Process the query so that we will save the date of birth
	if ($mysqli->query($sql)) {
	  echo "Bookings has been sucessfully deleted.";
	} else {
	  return "Error: " . $sql . "<br>" . $mysqli->error;
	}

	// Close the connection after using it
	$mysqli->close();
?>