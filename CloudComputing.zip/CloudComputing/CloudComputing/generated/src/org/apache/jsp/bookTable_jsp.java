package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class bookTable_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List<String> _jspx_dependants;

  private org.glassfish.jsp.api.ResourceInjector _jspx_resourceInjector;

  public java.util.List<String> getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;

    try {
      response.setContentType("text/html;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;
      _jspx_resourceInjector = (org.glassfish.jsp.api.ResourceInjector) application.getAttribute("com.sun.appserv.jsp.resource.injector");

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<!DOCTYPE html>\n");
      out.write("<html lang=\"en\">\n");
      out.write("\n");
      out.write("<head>\n");
      out.write("  <meta charset=\"utf-8\">\n");
      out.write("  <meta content=\"width=device-width, initial-scale=1.0\" name=\"viewport\">\n");
      out.write("\n");
      out.write("  <title>Book A Table</title>\n");
      out.write("  <meta content=\"\" name=\"description\">\n");
      out.write("  <meta content=\"\" name=\"keywords\">\n");
      out.write("\n");
      out.write("  <!-- Favicons -->\n");
      out.write("  <link href=\"img/favicon.png\" rel=\"icon\">\n");
      out.write("  <link href=\"img/apple-touch-icon.png\" rel=\"apple-touch-icon\">\n");
      out.write("\n");
      out.write("  <!-- Google Fonts -->\n");
      out.write("  <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n");
      out.write("  <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\n");
      out.write("  <link href=\"https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Amatic+SC:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap\" rel=\"stylesheet\">\n");
      out.write("\n");
      out.write("  <!-- Vendor CSS Files -->\n");
      out.write("  <link href=\"vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">\n");
      out.write("  <link href=\"vendor/bootstrap-icons/bootstrap-icons.css\" rel=\"stylesheet\">\n");
      out.write("  <link href=\"vendor/aos/aos.css\" rel=\"stylesheet\">\n");
      out.write("  <link href=\"vendor/glightbox/css/glightbox.min.css\" rel=\"stylesheet\">\n");
      out.write("  <link href=\"vendor/swiper/swiper-bundle.min.css\" rel=\"stylesheet\">\n");
      out.write("\n");
      out.write("  <!-- Template Main CSS File -->\n");
      out.write("  <link href=\"css/main.css\" rel=\"stylesheet\">\n");
      out.write("</head>\n");
      out.write("\n");
      out.write("<body>\n");
      out.write("\n");
      out.write("  <!-- ======= Header ======= -->\n");
      out.write("  <header id=\"header\" class=\"header fixed-top d-flex align-items-center\">\n");
      out.write("    <div class=\"container d-flex align-items-center justify-content-between\">\n");
      out.write("\n");
      out.write("      <a href=\"index.html\" class=\"logo d-flex align-items-center me-auto me-lg-0\">\n");
      out.write("        <!-- Uncomment the line below if you also wish to use an image logo -->\n");
      out.write("        <!-- <img src=\"assets/img/logo.png\" alt=\"\"> -->\n");
      out.write("        <h1>Yummy<span>.</span></h1>\n");
      out.write("      </a>\n");
      out.write("      <i class=\"mobile-nav-toggle mobile-nav-show bi bi-list\"></i>\n");
      out.write("      <i class=\"mobile-nav-toggle mobile-nav-hide d-none bi bi-x\"></i>\n");
      out.write("\n");
      out.write("    </div>\n");
      out.write("  </header><!-- End Header -->\n");
      out.write("\n");
      out.write(" \n");
      out.write("    <!-- ======= Book A Table Section ======= -->\n");
      out.write("    <section id=\"book-a-table\" class=\"book-a-table\" style=\"margin-top:10px;\">\n");
      out.write("      <div class=\"container\" data-aos=\"fade-up\">\n");
      out.write("\n");
      out.write("        <div class=\"section-header\">\n");
      out.write("          <h2>Book A Table</h2>\n");
      out.write("          <p>Book <span>Your Stay</span> With Us</p>\n");
      out.write("        </div>\n");
      out.write("\n");
      out.write("        <div class=\"row g-0\">\n");
      out.write("\n");
      out.write("          <div class=\"col-lg-4 reservation-img\" style=\"background-image: url(img/reservation.jpg);width:33%;\" data-aos=\"zoom-out\" data-aos-delay=\"200\"></div>\n");
      out.write("          <div class=\"col-lg-8 d-flex align-items-center reservation-form-bg\">\n");
      out.write("            <form action=\"forms/book-a-table.php\" method=\"post\" role=\"form\" class=\"php-email-form\" data-aos=\"fade-up\" data-aos-delay=\"100\" style=\"margin-top:60px;\">\n");
      out.write("              <div class=\"row gy-4\">\n");
      out.write("                <div class=\"col-lg-4 col-md-6\">\n");
      out.write("                  <input type=\"text\" name=\"name\" class=\"form-control\" id=\"name\" placeholder=\"Your Name\" data-rule=\"minlen:4\" data-msg=\"Please enter at least 4 chars\">\n");
      out.write("                  <div class=\"validate\"></div>\n");
      out.write("                </div>\n");
      out.write("                <div class=\"col-lg-4 col-md-6\">\n");
      out.write("                  <input type=\"text\" class=\"form-control\" name=\"phone\" id=\"phone\" placeholder=\"Your Phone\" data-rule=\"minlen:4\" data-msg=\"Please enter at least 4 chars\">\n");
      out.write("                  <div class=\"validate\"></div>\n");
      out.write("                </div>\n");
      out.write("                <div class=\"col-lg-4 col-md-6\">\n");
      out.write("                  <input type=\"text\" name=\"date\" class=\"form-control\" id=\"date\" placeholder=\"Date\" data-rule=\"minlen:4\" data-msg=\"Please enter at least 4 chars\">\n");
      out.write("                  <div class=\"validate\"></div>\n");
      out.write("                </div>\n");
      out.write("                <div class=\"col-lg-4 col-md-6\">\n");
      out.write("                  <input type=\"text\" class=\"form-control\" name=\"time\" id=\"time\" placeholder=\"Time\" data-rule=\"minlen:4\" data-msg=\"Please enter at least 4 chars\">\n");
      out.write("                  <div class=\"validate\"></div>\n");
      out.write("                </div>\n");
      out.write("                <div class=\"col-lg-4 col-md-6\">\n");
      out.write("                  <input type=\"number\" class=\"form-control\" name=\"people\" id=\"people\" placeholder=\"# of people\" data-rule=\"minlen:1\" data-msg=\"Please enter at least 1 chars\">\n");
      out.write("                  <div class=\"validate\"></div>\n");
      out.write("                </div>\n");
      out.write("              </div>\n");
      out.write("              <div class=\"mb-3\">\n");
      out.write("                <div class=\"loading\">Loading</div>\n");
      out.write("                <div class=\"error-message\"></div>\n");
      out.write("                <div class=\"sent-message\">Your booking request was sent. We will call back or send an Email to confirm your reservation. Thank you!</div>\n");
      out.write("              </div>\n");
      out.write("              <div class=\"text-center\"><button style=\"margin-top:50px;\" type=\"submit\">Book a Table</button></div>\n");
      out.write("            </form>\n");
      out.write("          </div><!-- End Reservation Form -->\n");
      out.write("\n");
      out.write("        </div>\n");
      out.write("\n");
      out.write("      </div>\n");
      out.write("    </section><!-- End Book A Table Section -->\n");
      out.write("\n");
      out.write("  <!-- ======= Footer ======= -->\n");
      out.write("  <footer id=\"footer\" class=\"footer\">\n");
      out.write("\n");
      out.write("    <div class=\"container\">\n");
      out.write("      <div class=\"row gy-3\">\n");
      out.write("        <div class=\"col-lg-3 col-md-6 d-flex\">\n");
      out.write("          <i class=\"bi bi-geo-alt icon\"></i>\n");
      out.write("          <div>\n");
      out.write("            <h4>Address</h4>\n");
      out.write("            <p>\n");
      out.write("              A108 Adam Street <br>\n");
      out.write("              New York, NY 535022 - US<br>\n");
      out.write("            </p>\n");
      out.write("          </div>\n");
      out.write("\n");
      out.write("        </div>\n");
      out.write("\n");
      out.write("        <div class=\"col-lg-3 col-md-6 footer-links d-flex\">\n");
      out.write("          <i class=\"bi bi-telephone icon\"></i>\n");
      out.write("          <div>\n");
      out.write("            <h4>Reservations</h4>\n");
      out.write("            <p>\n");
      out.write("              <strong>Phone:</strong> +1 5589 55488 55<br>\n");
      out.write("              <strong>Email:</strong> info@example.com<br>\n");
      out.write("            </p>\n");
      out.write("          </div>\n");
      out.write("        </div>\n");
      out.write("\n");
      out.write("        <div class=\"col-lg-3 col-md-6 footer-links d-flex\">\n");
      out.write("          <i class=\"bi bi-clock icon\"></i>\n");
      out.write("          <div>\n");
      out.write("            <h4>Opening Hours</h4>\n");
      out.write("            <p>\n");
      out.write("              <strong>Mon-Sat: 11AM</strong> - 23PM<br>\n");
      out.write("              Sunday: Closed\n");
      out.write("            </p>\n");
      out.write("          </div>\n");
      out.write("        </div>\n");
      out.write("\n");
      out.write("        <div class=\"col-lg-3 col-md-6 footer-links\">\n");
      out.write("          <h4>Follow Us</h4>\n");
      out.write("          <div class=\"social-links d-flex\">\n");
      out.write("            <a href=\"#\" class=\"twitter\"><i class=\"bi bi-twitter\"></i></a>\n");
      out.write("            <a href=\"#\" class=\"facebook\"><i class=\"bi bi-facebook\"></i></a>\n");
      out.write("            <a href=\"#\" class=\"instagram\"><i class=\"bi bi-instagram\"></i></a>\n");
      out.write("            <a href=\"#\" class=\"linkedin\"><i class=\"bi bi-linkedin\"></i></a>\n");
      out.write("          </div>\n");
      out.write("        </div>\n");
      out.write("\n");
      out.write("      </div>\n");
      out.write("    </div>\n");
      out.write("\n");
      out.write("    <div class=\"container\">\n");
      out.write("      <div class=\"copyright\">\n");
      out.write("        &copy; Copyright <strong><span>Yummy</span></strong>. All Rights Reserved\n");
      out.write("      </div>\n");
      out.write("      <div class=\"credits\">\n");
      out.write("        <!-- All the links in the footer should remain intact. -->\n");
      out.write("        <!-- You can delete the links only if you purchased the pro version. -->\n");
      out.write("        <!-- Licensing information: https://bootstrapmade.com/license/ -->\n");
      out.write("        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/yummy-bootstrap-restaurant-website-template/ -->\n");
      out.write("        Designed by <a href=\"https://bootstrapmade.com/\">BootstrapMade</a>\n");
      out.write("      </div>\n");
      out.write("    </div>\n");
      out.write("\n");
      out.write("  </footer><!-- End Footer -->\n");
      out.write("  <!-- End Footer -->\n");
      out.write("\n");
      out.write("  <a href=\"#\" class=\"scroll-top d-flex align-items-center justify-content-center\"><i class=\"bi bi-arrow-up-short\"></i></a>\n");
      out.write("\n");
      out.write("  <div id=\"preloader\"></div>\n");
      out.write("\n");
      out.write("  <!-- Vendor JS Files -->\n");
      out.write("  <script src=\"vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>\n");
      out.write("  <script src=\"vendor/aos/aos.js\"></script>\n");
      out.write("  <script src=\"vendor/glightbox/js/glightbox.min.js\"></script>\n");
      out.write("  <script src=\"vendor/purecounter/purecounter_vanilla.js\"></script>\n");
      out.write("  <script src=\"vendor/swiper/swiper-bundle.min.js\"></script>\n");
      out.write("  <script src=\"vendor/php-email-form/validate.js\"></script>\n");
      out.write("\n");
      out.write("  <!-- Template Main JS File -->\n");
      out.write("  <script src=\"js/main.js\"></script>\n");
      out.write("\n");
      out.write("</body>\n");
      out.write("\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
        else throw new ServletException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
