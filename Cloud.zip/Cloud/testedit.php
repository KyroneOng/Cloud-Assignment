<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<?php
       include 'dbinfo.inc';
       
        $mysqli = new mysqli($servername, $username, $password, $dbname);

	if ($mysqli->connect_errno) {
	  echo "Failed to connect to MySQL: " . $mysqli->connect_error;
	  exit();
	}
        
        if(count($_POST)>0) {
            mysqli_query($mysqli,"UPDATE bookings set name='" .$_POST['name'] ."',phone='" .$_POST['phone'] ."', date='". $_POST['date'] ."', time='" .$_POST['time']. "', people='". $_POST['people']. "' WHERE name='". $_POST['name']. "'");
            $message = "Record Modified Successfully";
            }
            $result = mysqli_query($mysqli,"SELECT * FROM bookings WHERE name='" . $_GET['name'] . "'");
            $row= mysqli_fetch_array($result);
        ?>
        <html>
        <head>
            <style>
		body{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			font-family: "Open Sans", sans-serif;
			background-size: cover;
			background-attachment:fixed;
		}

		.container{
			justify-content: center;
			align-items: center;
			margin: 0 auto;
			max-width: 800px;
			height:560px;
			background-color: #fbfbfb;
			display: flex;
			margin-top: 5em;
			padding-bottom: 20px;
                        padding-top: 20px;
		}

		.section1{
			width: 60%;
			margin-left:50px;
		}

		.section2{
			width:50%;
		}

		.section2 > img{
			width:100%;
			height:100%;
			margin: 10px 0px 0px 8px;
		}
		h1{
			text-align: center;
                      
		}
		h5{
			text-align: center;
			margin-top: -12px;
		}

		label{
			text-transform: uppercase;
			font-size: 11px;
			color: grey;
		}

		input{
			border: none;
			border-bottom: 1px solid lightgray;
			background-color: #fbfbfb;
			width: 90%;
			position: relative;
			top: -12px;
			background-color: #fbfbfb;
			padding: 5px;
		}

		input:focus{
			outline: none;
			border-bottom: 1px solid red;
			font-size: 14px;
			font-weight: bold;
			transition: 0.5s
		}

		#password:focus{
			color: red;
			font-size: 16px;
			font-weight: bold;
			transition: 0.5s
		}

		#btn{
			border: none;
			background-color: black;
			width:120px;
			border-radius: 20px;
			padding: 10px;
			color: white;
			margin-top: 15px;
		}

		p{
			font-size: x-small;
		}

		.line{
			border-bottom: 1px solid lightgray;
			width: 100%;
			margin-top:50px;
		}

		h6{
			position: relative;
			top: -8px;
			font-size: 12px;
		}

		#btn:hover{
			box-shadow: 0 0 10px black;
			background-color: white;
			color: black;
			transition: 0.5s
		}
	</style>
        <head>
        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <title>Edit</title>
        <meta content="" name="keywords">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">
    </head>     
        </head>
        <body>
        <form name="frmUser" method="post" action="">
        <div><?php if(isset($message)) { echo $message; } ?>
        </div>
            
             <body>
      
		<div class="container">  
		    <div class="section1"> <!--form section -->
				<form action="" method="POST">
                                    <h1 style="margin-right:40px; color: black;">EDIT PAGE</h1><br><br>
					<div class="formGroup">
						<p> <label for="name">Customer Name </label></p>
						<input type="hidden" id="name" name="name" autocomplete="off" value="<?php echo $row['name']; ?>">
                                                <input type="text" name="name"  value="<?php echo $row['name']; ?>">
					</div> 
					<div class="formGroup">
						<p> <label for="phone">Phone Number </label></p>
						<input type="text" id="phone" name="phone" autocomplete="off" value="<?php echo $row['phone']; ?>">
					</div>
					<div class="formGroup">
						<p> <label for="date">Booking Date </label></p>
						<input type="date" id="date" name="date" autocomplete="off" value="<?php echo $row['date']; ?>">
					</div>
					<div class="formGroup">
						<p> <label for="time">Booking Time </label></p>
						<input type="time" id="time" name="time" autocomplete="off" value="<?php echo $row['time']; ?>">
					</div>
					<div class="formGroup">
						<p> <label for="people">Quantity Of People </label></p>
						<input type="number" min="1" max="20" id="people" name="people" autocomplete="off" value="<?php echo $row['people']; ?>">
					</div>
					<input type="submit" id="btn" value="EDIT"/>     
			    </form>
                                     <a href="listtable.php"><input type="button" id="btn" value="BACK"/></a>
			</div>
		</div>
        </body>
        </html>
