<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <title>Edit</title>
        <meta content="" name="keywords">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">
    </head>     
       
	<style>
		body{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			font-family: "Open Sans", sans-serif;
			background-size: cover;
			background-attachment:fixed;
		}

		.container{
			justify-content: center;
			align-items: center;
			margin: 0 auto;
			max-width: 800px;
			height:560px;
			background-color: #fbfbfb;
			display: flex;
			margin-top: 5em;
			padding-bottom: 20px;
                        padding-top: 20px;
		}

		.section1{
			width: 60%;
			margin-left:50px;
		}

		.section2{
			width:50%;
		}

		.section2 > img{
			width:100%;
			height:100%;
			margin: 10px 0px 0px 8px;
		}
		h1{
			text-align: center;
                      
		}
		h5{
			text-align: center;
			margin-top: -12px;
		}

		label{
			text-transform: uppercase;
			font-size: 11px;
			color: grey;
		}

		input{
			border: none;
			border-bottom: 1px solid lightgray;
			background-color: #fbfbfb;
			width: 90%;
			position: relative;
			top: -12px;
			background-color: #fbfbfb;
			padding: 5px;
		}

		input:focus{
			outline: none;
			border-bottom: 1px solid red;
			font-size: 14px;
			font-weight: bold;
			transition: 0.5s
		}

		#password:focus{
			color: red;
			font-size: 16px;
			font-weight: bold;
			transition: 0.5s
		}

		#btn{
			border: none;
			background-color: black;
			width:120px;
			border-radius: 20px;
			padding: 10px;
			color: white;
			margin-top: 15px;
		}

		p{
			font-size: x-small;
		}

		.line{
			border-bottom: 1px solid lightgray;
			width: 100%;
			margin-top:50px;
		}

		h6{
			position: relative;
			top: -8px;
			font-size: 12px;
		}

		#btn:hover{
			box-shadow: 0 0 10px black;
			background-color: white;
			color: black;
			transition: 0.5s
		}
	</style>
    <body>
      
		<div class="container">  
		    <div class="section1"> <!--form section -->
				<form action="" method="POST">
                                    <h1 style="margin-right:40px; color: black;">EDIT PAGE</h1><br><br>
					<div class="formGroup">
						<p> <label for="name">Customer Name </label></p>
						<input type="text" id="name" name="name" autocomplete="off">
					</div> 
					<div class="formGroup">
						<p> <label for="phone">Phone Number </label></p>
						<input type="text" id="phone" name="phone" autocomplete="off">
					</div>
					<div class="formGroup">
						<p> <label for="date">Booking Date </label></p>
						<input type="date" id="date" name="date" autocomplete="off">
					</div>
					<div class="formGroup">
						<p> <label for="time">Booking Time </label></p>
						<input type="time" id="time" name="time" autocomplete="off">
					</div>
					<div class="formGroup">
						<p> <label for="people">Quantity Of People </label></p>
						<input type="number" min="1" max="20" id="people" name="people" autocomplete="off">
					</div>
					<input type="submit" id="btn" value="EDIT"/>
			    </form>
			</div>
		</div>
        <?php
        $request = $_REQUEST; //a PHP Super Global variable which used to collect data after submitting it from the form
	$name = $request['name']; 
        $phone = $request['phone'];
        $date = $request['date'];
        $time = $request['time'];
        $people = $request['people'];

	$servername = ""; //set the servername
	$username = ""; //set the server username
	$password = ""; // set the server password (you must put password here if your using live server)
	$dbname = "bookings"; // set the table name

	$mysqli = new mysqli($servername, $username, $password, $dbname);

	if ($mysqli->connect_errno) {
	  echo "Failed to connect to MySQL: " . $mysqli->connect_error;
	  exit();
	}

	// Set the INSERT SQL data
	$sql = "UPDATE bookings SET phone='".$phone."', date='".$date."', time='".$time."', people='".$people."' WHERE name='".$name."'";

	// Process the query so that we will save the date of birth
	if ($mysqli->query($sql)) {
	  echo "Bookings has been sucessfully updated.";
	} else {
	  return "Error: " . $sql . "<br>" . $mysqli->error;
	}

	// Close the connection after using it
	$mysqli->close();
        ?> 
        
     <div id="preloader"></div>
     <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

     <!-- Vendor JS Files -->
     <script src="assets/vendor/aos/aos.js"></script>
     <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
     <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
     <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
     <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
     <script src="assets/vendor/php-email-form/validate.js"></script>

     <!-- Template Main JS File -->
     <script src="assets/js/main.js"></script>
    </body>
   
</html>

